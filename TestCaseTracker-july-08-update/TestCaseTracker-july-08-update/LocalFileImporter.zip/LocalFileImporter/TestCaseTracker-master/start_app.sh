#!/bin/bash

# Start the Node.js application
cd "$(dirname "$0")" 
npm run dev