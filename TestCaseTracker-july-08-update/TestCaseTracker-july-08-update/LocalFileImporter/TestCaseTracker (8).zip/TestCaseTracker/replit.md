# Replit Project Documentation

## Overview

This project is a modern web application built with React and Express.js, featuring a full-stack architecture with form handling, data visualization, and PDF generation capabilities. The application uses Drizzle ORM for database operations and includes a comprehensive UI component library built with Tailwind CSS.

## System Architecture

The application follows a client-server architecture with the following key characteristics:

### Frontend Architecture
- **Framework**: React 19.1.0 with modern hooks and functional components
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **Styling**: Tailwind CSS with custom animations and class variance authority for component styling
- **Form Handling**: React Hook Form with Zod schema validation via @hookform/resolvers

### Backend Architecture
- **Server Framework**: Express.js 5.1.0 for REST API endpoints
- **Database ORM**: Drizzle ORM with Zod integration for type-safe database operations
- **Validation**: Zod for runtime type checking and schema validation

## Key Components

### Database Layer
- **ORM**: Drizzle ORM provides type-safe database queries and migrations
- **Schema Validation**: Drizzle-Zod integration ensures database schema consistency with TypeScript types
- **Note**: The application is configured to work with Drizzle ORM, which supports multiple database providers

### UI Components
- **Icon System**: Lucide React for consistent iconography
- **Color Picker**: React Colorful for color selection interfaces
- **Charts & Visualization**: Recharts for data visualization components
- **Styling Utilities**: 
  - Class Variance Authority for component variant management
  - Tailwind Merge for efficient CSS class merging
  - Tailwind CSS Animate for smooth animations

### Document Generation
- **PDF Creation**: jsPDF with jsPDF AutoTable for generating formatted PDF documents
- **Use Case**: Likely used for reports, invoices, or data export functionality

### Form Management
- **Validation**: Zod schemas provide runtime type checking and validation rules
- **Form Library**: React Hook Form for efficient form state management
- **Integration**: @hookform/resolvers bridges React Hook Form with Zod validation

## Data Flow

1. **Client Requests**: Frontend components make API calls using TanStack React Query
2. **Server Processing**: Express.js routes handle incoming requests
3. **Database Operations**: Drizzle ORM executes type-safe database queries
4. **Data Validation**: Zod schemas validate data at both client and server levels
5. **Response Handling**: React Query manages caching and state updates
6. **UI Updates**: React components re-render based on updated state

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 19.1.0 with React DOM for frontend rendering
- **Server Framework**: Express.js for backend API development
- **Database**: Drizzle ORM (database provider to be determined)

### Development & Utility Libraries
- **Styling**: Tailwind CSS ecosystem for responsive design
- **Icons**: Lucide React for scalable vector icons
- **Charts**: Recharts for data visualization
- **PDF Generation**: jsPDF suite for document creation
- **Validation**: Zod for schema validation across the stack

## Deployment Strategy

The current configuration suggests a monorepo structure with both frontend and backend code. The application appears to be set up for:

- **Development**: Local development with hot reloading capabilities
- **Production**: Deployable as a full-stack application
- **Database**: Flexible database provider support through Drizzle ORM

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 05, 2025. Initial setup