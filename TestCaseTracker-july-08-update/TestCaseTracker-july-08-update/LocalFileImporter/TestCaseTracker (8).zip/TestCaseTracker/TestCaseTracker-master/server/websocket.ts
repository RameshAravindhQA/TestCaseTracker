
import { Server as SocketIOServer } from 'socket.io';
import { Server as HttpServer } from 'http';
import { storage } from './storage';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

interface User {
  id: number;
  name: string;
  email: string;
  avatar?: string;
}

interface ChatMessage {
  id: string;
  content: string;
  userId: number;
  user: User;
  timestamp: Date;
  type: 'text' | 'file' | 'image' | 'video' | 'audio';
  attachments?: MessageAttachment[];
  replyTo?: string;
  isPinned?: boolean;
  tags?: string[];
  edited?: boolean;
  editedAt?: Date;
  reactions?: { [emoji: string]: number[] }; // emoji -> user IDs
}

interface MessageAttachment {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
}

interface Room {
  id: string;
  name: string;
  type: 'direct' | 'group' | 'project';
  participants: number[];
  pinnedMessages: string[];
  lastActivity: Date;
}

interface JitsiCall {
  id: string;
  roomId: string;
  initiatorId: number;
  participants: number[];
  callType: 'audio' | 'video';
  startTime: Date;
  endTime?: Date;
  jitsiRoomName: string;
}

export class EnhancedChatWebSocketServer {
  private io: SocketIOServer;
  private connectedUsers: Map<string, { userId: number; socketId: string; user: User }> = new Map();
  private userSockets: Map<number, Set<string>> = new Map();
  private rooms: Map<string, Room> = new Map();
  private messages: Map<string, ChatMessage[]> = new Map();
  private activeTyping: Map<string, Set<number>> = new Map();
  private activeCalls: Map<string, JitsiCall> = new Map();

  constructor(server: HttpServer) {
    this.io = new SocketIOServer(server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"],
        credentials: true
      },
      path: '/socket.io'
    });

    this.setupSocketHandlers();
    this.setupFileUpload();
  }

  private setupFileUpload() {
    // Configure multer for chat attachments
    const chatStorage = multer.diskStorage({
      destination: (req, file, cb) => {
        const uploadDir = path.join(process.cwd(), 'uploads', 'chat-attachments');
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
      },
      filename: (req, file, cb) => {
        const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
        cb(null, uniqueName);
      }
    });

    const upload = multer({ 
      storage: chatStorage,
      limits: {
        fileSize: 100 * 1024 * 1024 // 100MB
      }
    });
  }

  private setupSocketHandlers() {
    this.io.on('connection', (socket) => {
      console.log(`Client connected: ${socket.id}`);

      // User authentication
      socket.on('authenticate', async (data: { userId: number; token?: string }) => {
        try {
          const user = await storage.getUser(data.userId);
          if (user) {
            const userInfo = {
              id: user.id,
              name: `${user.firstName} ${user.lastName || ''}`.trim(),
              email: user.email,
              avatar: user.profilePicture || undefined
            };

            this.connectedUsers.set(socket.id, {
              userId: user.id,
              socketId: socket.id,
              user: userInfo
            });

            if (!this.userSockets.has(user.id)) {
              this.userSockets.set(user.id, new Set());
            }
            this.userSockets.get(user.id)!.add(socket.id);

            socket.emit('authenticated', { user: userInfo });
            socket.broadcast.emit('user_online', userInfo);

            // Send user's rooms
            const userRooms = await this.getUserRooms(user.id);
            socket.emit('rooms_list', userRooms);
          }
        } catch (error) {
          socket.emit('auth_error', { message: 'Authentication failed' });
        }
      });

      // Join room
      socket.on('join_room', async (data: { roomId: string; roomType?: 'direct' | 'group' | 'project' }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        socket.join(data.roomId);
        
        // Initialize room if it doesn't exist
        if (!this.rooms.has(data.roomId)) {
          this.rooms.set(data.roomId, {
            id: data.roomId,
            name: data.roomId,
            type: data.roomType || 'group',
            participants: [userConnection.userId],
            pinnedMessages: [],
            lastActivity: new Date()
          });
        } else {
          const room = this.rooms.get(data.roomId)!;
          if (!room.participants.includes(userConnection.userId)) {
            room.participants.push(userConnection.userId);
          }
        }

        // Send recent messages
        const messages = this.messages.get(data.roomId) || [];
        const recentMessages = messages.slice(-50); // Last 50 messages
        socket.emit('room_messages', { roomId: data.roomId, messages: recentMessages });

        // Send pinned messages
        const room = this.rooms.get(data.roomId)!;
        const pinnedMessages = messages.filter(msg => room.pinnedMessages.includes(msg.id));
        socket.emit('pinned_messages', { roomId: data.roomId, messages: pinnedMessages });

        socket.to(data.roomId).emit('user_joined_room', {
          roomId: data.roomId,
          user: userConnection.user
        });
      });

      // Send message
      socket.on('send_message', async (data: {
        roomId: string;
        content: string;
        type?: 'text' | 'file' | 'image' | 'video' | 'audio';
        attachments?: MessageAttachment[];
        replyTo?: string;
        tags?: string[];
      }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const message: ChatMessage = {
          id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          content: data.content,
          userId: userConnection.userId,
          user: userConnection.user,
          timestamp: new Date(),
          type: data.type || 'text',
          attachments: data.attachments || [],
          replyTo: data.replyTo,
          tags: data.tags || [],
          reactions: {}
        };

        // Store message
        if (!this.messages.has(data.roomId)) {
          this.messages.set(data.roomId, []);
        }
        this.messages.get(data.roomId)!.push(message);

        // Update room last activity
        const room = this.rooms.get(data.roomId);
        if (room) {
          room.lastActivity = new Date();
        }

        // Broadcast to room
        this.io.to(data.roomId).emit('new_message', {
          roomId: data.roomId,
          message
        });

        // Save to database
        try {
          await storage.createChatMessage({
            projectId: data.roomId.startsWith('project_') ? parseInt(data.roomId.replace('project_', '')) : null,
            userId: userConnection.userId,
            message: data.content,
            type: data.type || 'text',
            replyToId: data.replyTo ? parseInt(data.replyTo.replace('msg_', '')) : null,
            attachments: JSON.stringify(data.attachments || []),
            tags: JSON.stringify(data.tags || [])
          });
        } catch (error) {
          console.error('Failed to save message to database:', error);
        }
      });

      // Edit message
      socket.on('edit_message', async (data: { roomId: string; messageId: string; newContent: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const roomMessages = this.messages.get(data.roomId);
        if (!roomMessages) return;

        const messageIndex = roomMessages.findIndex(msg => msg.id === data.messageId);
        if (messageIndex === -1) return;

        const message = roomMessages[messageIndex];
        if (message.userId !== userConnection.userId) return; // Only author can edit

        message.content = data.newContent;
        message.edited = true;
        message.editedAt = new Date();

        this.io.to(data.roomId).emit('message_edited', {
          roomId: data.roomId,
          messageId: data.messageId,
          newContent: data.newContent,
          editedAt: message.editedAt
        });
      });

      // Delete message
      socket.on('delete_message', async (data: { roomId: string; messageId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const roomMessages = this.messages.get(data.roomId);
        if (!roomMessages) return;

        const messageIndex = roomMessages.findIndex(msg => msg.id === data.messageId);
        if (messageIndex === -1) return;

        const message = roomMessages[messageIndex];
        if (message.userId !== userConnection.userId) return; // Only author can delete

        roomMessages.splice(messageIndex, 1);

        this.io.to(data.roomId).emit('message_deleted', {
          roomId: data.roomId,
          messageId: data.messageId
        });
      });

      // Pin/Unpin message
      socket.on('toggle_pin_message', (data: { roomId: string; messageId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const room = this.rooms.get(data.roomId);
        if (!room) return;

        const roomMessages = this.messages.get(data.roomId);
        if (!roomMessages) return;

        const message = roomMessages.find(msg => msg.id === data.messageId);
        if (!message) return;

        const isPinned = room.pinnedMessages.includes(data.messageId);
        
        if (isPinned) {
          room.pinnedMessages = room.pinnedMessages.filter(id => id !== data.messageId);
          message.isPinned = false;
        } else {
          room.pinnedMessages.push(data.messageId);
          message.isPinned = true;
        }

        this.io.to(data.roomId).emit('message_pin_toggled', {
          roomId: data.roomId,
          messageId: data.messageId,
          isPinned: !isPinned
        });
      });

      // Add reaction
      socket.on('add_reaction', (data: { roomId: string; messageId: string; emoji: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const roomMessages = this.messages.get(data.roomId);
        if (!roomMessages) return;

        const message = roomMessages.find(msg => msg.id === data.messageId);
        if (!message) return;

        if (!message.reactions) message.reactions = {};
        if (!message.reactions[data.emoji]) message.reactions[data.emoji] = [];

        const userReactionIndex = message.reactions[data.emoji].indexOf(userConnection.userId);
        if (userReactionIndex === -1) {
          message.reactions[data.emoji].push(userConnection.userId);
        } else {
          message.reactions[data.emoji].splice(userReactionIndex, 1);
          if (message.reactions[data.emoji].length === 0) {
            delete message.reactions[data.emoji];
          }
        }

        this.io.to(data.roomId).emit('reaction_updated', {
          roomId: data.roomId,
          messageId: data.messageId,
          emoji: data.emoji,
          reactions: message.reactions
        });
      });

      // Global search
      socket.on('global_search', (data: { query: string; roomId?: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const results: any[] = [];
        const query = data.query.toLowerCase();

        const searchInMessages = (messages: ChatMessage[], roomId: string) => {
          return messages.filter(msg => {
            const contentMatch = msg.content.toLowerCase().includes(query);
            const userMatch = msg.user.name.toLowerCase().includes(query);
            const tagMatch = msg.tags?.some(tag => tag.toLowerCase().includes(query));
            return contentMatch || userMatch || tagMatch;
          }).map(msg => ({
            ...msg,
            roomId,
            highlight: this.highlightText(msg.content, query)
          }));
        };

        if (data.roomId) {
          // Search in specific room
          const messages = this.messages.get(data.roomId) || [];
          results.push(...searchInMessages(messages, data.roomId));
        } else {
          // Search across all rooms user has access to
          this.messages.forEach((messages, roomId) => {
            const room = this.rooms.get(roomId);
            if (room && room.participants.includes(userConnection.userId)) {
              results.push(...searchInMessages(messages, roomId));
            }
          });
        }

        socket.emit('search_results', {
          query: data.query,
          results: results.slice(0, 50) // Limit to 50 results
        });
      });

      // Typing indicators
      socket.on('typing_start', (data: { roomId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        if (!this.activeTyping.has(data.roomId)) {
          this.activeTyping.set(data.roomId, new Set());
        }
        this.activeTyping.get(data.roomId)!.add(userConnection.userId);

        socket.to(data.roomId).emit('user_typing', {
          roomId: data.roomId,
          userId: userConnection.userId,
          user: userConnection.user
        });
      });

      socket.on('typing_stop', (data: { roomId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const typingUsers = this.activeTyping.get(data.roomId);
        if (typingUsers) {
          typingUsers.delete(userConnection.userId);
        }

        socket.to(data.roomId).emit('user_stopped_typing', {
          roomId: data.roomId,
          userId: userConnection.userId
        });
      });

      // Jitsi Call Management
      socket.on('initiate_call', (data: { roomId: string; callType: 'audio' | 'video' }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const jitsiRoomName = `testcase-${data.roomId}-${Date.now()}`;
        const call: JitsiCall = {
          id: `call_${Date.now()}`,
          roomId: data.roomId,
          initiatorId: userConnection.userId,
          participants: [userConnection.userId],
          callType: data.callType,
          startTime: new Date(),
          jitsiRoomName
        };

        this.activeCalls.set(call.id, call);

        // Notify room participants
        socket.to(data.roomId).emit('call_initiated', {
          call,
          initiator: userConnection.user,
          jitsiUrl: `https://meet.jit.si/${jitsiRoomName}`
        });

        socket.emit('call_created', {
          call,
          jitsiUrl: `https://meet.jit.si/${jitsiRoomName}`
        });
      });

      socket.on('join_call', (data: { callId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const call = this.activeCalls.get(data.callId);
        if (!call) return;

        if (!call.participants.includes(userConnection.userId)) {
          call.participants.push(userConnection.userId);
        }

        this.io.to(call.roomId).emit('user_joined_call', {
          callId: data.callId,
          user: userConnection.user,
          jitsiUrl: `https://meet.jit.si/${call.jitsiRoomName}`
        });
      });

      socket.on('leave_call', (data: { callId: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        const call = this.activeCalls.get(data.callId);
        if (!call) return;

        call.participants = call.participants.filter(id => id !== userConnection.userId);

        if (call.participants.length === 0) {
          call.endTime = new Date();
          this.activeCalls.delete(data.callId);
          this.io.to(call.roomId).emit('call_ended', { callId: data.callId });
        } else {
          this.io.to(call.roomId).emit('user_left_call', {
            callId: data.callId,
            user: userConnection.user
          });
        }
      });

      // File upload handling
      socket.on('upload_file', async (data: { roomId: string; file: ArrayBuffer; fileName: string; fileType: string }) => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (!userConnection) return;

        try {
          // Save file
          const uploadDir = path.join(process.cwd(), 'uploads', 'chat-attachments');
          if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
          }

          const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}-${data.fileName}`;
          const filePath = path.join(uploadDir, uniqueName);
          
          fs.writeFileSync(filePath, Buffer.from(data.file));

          const attachment: MessageAttachment = {
            id: `att_${Date.now()}`,
            name: data.fileName,
            url: `/uploads/chat-attachments/${uniqueName}`,
            type: data.fileType,
            size: data.file.byteLength
          };

          socket.emit('file_uploaded', {
            roomId: data.roomId,
            attachment
          });
        } catch (error) {
          socket.emit('upload_error', { message: 'Failed to upload file' });
        }
      });

      // Disconnect handling
      socket.on('disconnect', () => {
        const userConnection = this.connectedUsers.get(socket.id);
        if (userConnection) {
          // Remove from typing indicators
          this.activeTyping.forEach((typingUsers, roomId) => {
            if (typingUsers.has(userConnection.userId)) {
              typingUsers.delete(userConnection.userId);
              socket.to(roomId).emit('user_stopped_typing', {
                roomId,
                userId: userConnection.userId
              });
            }
          });

          // Remove from user sockets
          const userSockets = this.userSockets.get(userConnection.userId);
          if (userSockets) {
            userSockets.delete(socket.id);
            if (userSockets.size === 0) {
              this.userSockets.delete(userConnection.userId);
              socket.broadcast.emit('user_offline', userConnection.user);
            }
          }

          this.connectedUsers.delete(socket.id);
        }
        console.log(`Client disconnected: ${socket.id}`);
      });
    });
  }

  private highlightText(text: string, query: string): string {
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  }

  private async getUserRooms(userId: number): Promise<Room[]> {
    const rooms: Room[] = [];
    
    // Get direct conversations
    try {
      const conversations = await storage.getUserConversations(userId);
      for (const conv of conversations) {
        rooms.push({
          id: `conv_${conv.id}`,
          name: conv.name,
          type: conv.type as 'direct' | 'group',
          participants: conv.participants || [],
          pinnedMessages: [],
          lastActivity: new Date(conv.updatedAt || conv.createdAt)
        });
      }
    } catch (error) {
      console.error('Failed to get user conversations:', error);
    }

    // Get project rooms
    try {
      const projects = await storage.getProjectsByUserId(userId);
      for (const project of projects) {
        rooms.push({
          id: `project_${project.id}`,
          name: `Project: ${project.name}`,
          type: 'project',
          participants: [], // Will be populated from project members
          pinnedMessages: [],
          lastActivity: new Date(project.createdAt)
        });
      }
    } catch (error) {
      console.error('Failed to get user projects:', error);
    }

    return rooms;
  }

  public broadcast(event: string, data: any) {
    this.io.emit(event, data);
  }

  public sendToUser(userId: number, event: string, data: any) {
    const userSockets = this.userSockets.get(userId);
    if (userSockets) {
      userSockets.forEach(socketId => {
        this.io.to(socketId).emit(event, data);
      });
    }
  }

  public sendToRoom(roomId: string, event: string, data: any) {
    this.io.to(roomId).emit(event, data);
  }
}

export { EnhancedChatWebSocketServer as ChatWebSocketServer };
