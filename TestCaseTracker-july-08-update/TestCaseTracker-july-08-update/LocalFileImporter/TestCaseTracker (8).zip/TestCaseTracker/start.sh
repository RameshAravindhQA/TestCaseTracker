#!/bin/bash
echo "🚀 Starting Test Case Tracker Application..."
cd TestCaseTracker-master && npm run dev